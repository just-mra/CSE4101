const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

const connection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'lab4'
});

connection.connect(function(error){
    if(!!error) console.log(error);
    else console.log('Database Connected!');
}); 

//set views file
app.set('views',path.join(__dirname,'views'));
			
//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));



app.get('/',(req, res) => {
    // res.send('CRUD Operation using NodeJS / ExpressJS / MySQL');
    let sql = "SELECT * FROM studentinformation";
    let query = connection.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('userIndex', {
            title : 'Student Information',
            users : rows
        });
    });
});

app.get('/add',(req, res) => {
    res.render('studentAdd', {
        title : 'Student Information'
    });
});

app.post('/save',(req, res) => { 
    let data = {
        FirstName: req.body.firstName, 
        LastName: req.body.lastName, 
        Department: req.body.department,
        Roll: req.body.roll, 
        Gender: req.body.gender, 
        Email: req.body.email,
        MobileNumber: req.body.mobileNumber, 
        FavoriteIcecreamFlavor: req.body.favoriteIcecreamFlavor, 
        Address: req.body.address,
        HomeDistrict: req.body.homeDistrict
    };

    let sql = "INSERT INTO studentinformation SET ?";
    let query = connection.query(sql, data,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});

app.get('/update/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `Select * from studentinformation where studentId = ${userId}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.render('studentUpdate', {
            title : 'Student Information',
            user : result[0]
        });
    });
});

app.post('/update',(req, res) => {
    const userId = req.body.id;
    let sql = `update studentinformation SET FirstName= "${req.body.firstName}", LastName= "${req.body.lastName}", Department= "${req.body.department}", Roll= ${req.body.roll}, Gender="${req.body.gender}", Email= "${req.body.email}", MobileNumber= "${req.body.mobileNumber}", FavoriteIcecreamFlavor="${req.body.favoriteIcecreamFlavor}", Address= "${req.body.address}", HomeDistrict= "${req.body.homeDistrict}" where StudentId =${userId}`;
    let query = connection.query(sql,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});

app.get('/delete/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from studentinformation where StudentId = ${userId}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.redirect('/');
    });
});


// Server Listening
app.listen(3000, () => {
    console.log('Server is running at port 3000');
});